/*Usamos la conexión correcta*/
USE SYS;

/*Muestra la pdb*/
SHOW CON_NAME;

/*Muestra la pdb en cierta dba*/
SELECT PDB_NAME FROM DBA_PDBS;

/*Trabajamos en cierto container*/
ALTER SESSION SET CONTAINER = XEPDB1;

/*Muestra la pdb en cierta dba*/
SELECT PDB_NAME FROM DBA_PDBS;

/*Trabajamos en cierto container*/
ALTER SESSION SET CONTAINER = CDB$ROOT;

/*Muestra la pdb en cierta dba*/
SELECT PDB_NAME FROM DBA_PDBS;

/*Muestra la pdb*/
SHOW CON_NAME;

/*Conectarme a la cdb como sysdba*/
CREATE PLUGGABLE DATABASE PDB_NAME
    ADMIN USER admin IDENTIFIED BY contraseña
    FILE_NAME_CONVERT = ('/ruta/a/pdbseed/', '/ruta/a/pdb_name/');

/*Ejecutar*/
ALTER PLUGGABLE DATABASE PDB_NAME OPEN;

/*lISTAR LOS PDBS*/
SELECT CON_ID, NAME, OPEN_MODE FROM V$PDBS;

/*Trabajamos en cierto conatainer*/
ALTER SESSION SET CONTAINER = <PDB_NAME>;

/*abre todos*/
ALTER PLUGGABLE DATABASE ALL OPEN;

/*Cerrar*/
ALTER PLUGGABLE DATABASE pdb_alumnos CLOSE
IMMEDIATE;

/*Muestra la pdb en cierta dba*/
select name, cdb from v$DATABASE;

/*Listar todas las pdbs disponibles*/
SHOW PDBS;

/*Conectarme a la cdb como sysdba*/
CREATE PLUGGABLE DATABASE pdb_alumnos
    ADMIN USER admin_alumnos IDENTIFIED BY Oracle123
    STORAGE UNLIMITED
    FILE_NAME_CONVERT = (
        '/opt/oracle/oradata/XE/pdbseed/',
        '/opt/oracle/oradata/XE/pdb_alumnos/'
    );
    
/*Ejecutamos la database*/
ALTER PLUGGABLE DATABASE pdb_alumnos OPEN;

/*Ejecutamos la database*/
ALTER SESSION SET CONTAINER = pdb_alumnos;

/*Creamos la tabla*/
CREATE TABLE if not exists estudiantes (
    id_ESTUDIANTE NUMBER PRIMARY KEY,
    nombre VARCHAR2(100),
    email VARCHAR2(100) UNIQUE,
    fecha_registro DATE DEFAULT SYSDATE
);

/*Insertamos en la tabla*/
INSERT INTO estudiantes (id_ESTUDIANTE, nombre, email) VALUES (1, 'Ana Perez', '3@GMAIL.COM');
INSERT INTO estudiantes (id_ESTUDIANTE, nombre, email) VALUES (2, 'Luis Gomez', '2@GMAIL.COM');
INSERT INTO estudiantes (id_ESTUDIANTE, nombre, email) VALUES (3, 'Marta Ruiz', '1@GMAIL.COM');

/*Mostramos la tabla*/
select * from estudiantes;
commit;


/*
DROP PLUGGABLE DATABASE pdb_alumnos INCLUDING DATAFILES;
*/

/*
—-------------------------
	Parte 2
—-------------------------
*/


/*
crear usuario comun  con sys (en el root)
asignarle permisos create session y dba
el usuario local se crea en la pdb (en la pdb)
asignarle permisos de create session
*/

/*Se crea el usuario con su contraseña en el root*/
ALTER SESSION SET CONTAINER = CDB$ROOT;
create user c##Ivan identified by Oracle123;

/*Se le asigna el permiso de create session*/
grant create session to c##Ivan;

/*Se le asigna el permiso DBA*/
grant DBA to c##Ivan;

/*Se crea el usuario con su contraseña en el pdb asignado en este caso: pdb_alumnos*/
create user Lope identified by Oracle123;

/*Se le asigna el permiso de create session*/
ALTER SESSION SET CONTAINER = pdb_alumnos;
grant create session to Lope;




/*
—-------------------------
	Parte 3
—-------------------------
*/



/*para cerrar la pdb tenemos que estar en el root*/

ALTER SESSION SET CONTAINER = CDB$ROOT;
ALTER PLUGGABLE DATABASE pdb_alumnos CLOSE IMMEDIATE;

/*crearemos una copia directamente una copia desde la pdb*/
CREATE PLUGGABLE DATABASE pdb_alumnos_copia FROM pdb_alumnos FILE_NAME_CONVERT = ('/opt/oracle/oradata/XE/pdb_alumnos/', '/opt/oracle/oradata/XE/pdb_alumnos_copia/');

/*Ambas bases de datos tienen que estar en open para utilizarlas*/
ALTER PLUGGABLE DATABASE pdb_alumnos OPEN;
ALTER PLUGGABLE DATABASE pdb_alumnos_copia OPEN;

/*verificar con*/
show pdbs;
/*y debe aparecer la copia en la lista*/
/*cambiar la session del root a la copia*/
ALTER SESSION SET CONTAINER = pdb_alumnos_copia;

/*se usa como tabla normal.comprobar con un*/
select * from estudiantes;

/*para borrar una pdb primero debemos asegurarnos de que no haya sesiones activas
nos vamos al root*/
ALTER SESSION SET CONTAINER = CDB$ROOT;

/*verificamos el estado de las pdbs antes de borrarla*/
select pdb_name, status FROM cdb_pdbs WHERE pdb_name IN ('PDB_ALUMNOS', 'PDB_ALUMNOS_COPIA');

/*para cerrar todas las sesiones activas*/

begin
for ses In (select sid, serial# from v$session where con_id = (select con_id from v$pdbs where name = 'PDB_ALUMNOS'))
loop
EXECUTE IMMEDIATE 'alter system kill session ''' || ses.sid || ',' || ses.serial# || ''' IMMEDIATE';
end loop;
end;
/


/*cerramos la pdbs con este comando*/ 
ALTER PLUGGABLE DATABASE pdb_alumnos CLOSE IMMEDIATE;
ALTER PLUGGABLE DATABASE pdb_alumnos_copia CLOSE IMMEDIATE;
/*tienen que estar en MOUNTED*/
SHOW PDBS;

/*eliminar la pdb y sus archivos*/
DROP PLUGGABLE DATABASE pdb_alumnos INCLUDING DATAFILES;
DROP PLUGGABLE DATABASE pdb_alumnos_copia INCLUDING DATAFILES;

/*con*/ SHOW PDBS; /*verificamos si se han borrado correctamente no apareciendo en la lista*/

/*
—-------------------------
	Parte 4
—-------------------------
*/



/*Crear el tablespace*/
CREATE TABLESPACE pruebas DATAFILE '/opt/oracle/oradata/pruebas.dbf'',' SIZE 100M AUTOEXTEND ON;

/*verificar el tablespace*/
SELECT tablespace_name, bytes from dba_data_files;

/*Borrar el tablespace*/
DROP TABLESPACE pruebas INCLUDING CONTENTS AND DATAFILES;




/*Crear el tablespace*/
CREATE TABLESPACE pruebas DATAFILE '/opt/oracle/oradata/pruebas.dbf'',' SIZE 100M AUTOEXTEND ON;

/*verificar el tablespace*/
SELECT tablespace_name, bytes from dba_data_files;

/*Modificar el tablespace*/
alter database DATAFILE '/opt/oracle/oradata/pruebas.dbf'',' RESIZE 150M;

alter tablespace pruebas ADD DATAFILE '/opt/oracle/oradata/pruebas2.dbf'',' SIZE 50M;

/*COMPROBAR*/
SELECT tablespace_name, file_name, bytes / 1024 / 1024 AS M FROM dba_data_files;


DROP TABLESPACE tienda INCLUDING CONTENTS AND DATAFILES;

/*
—-------------------------
	Parte 5
—-------------------------
*/
ALTER SESSION SET CONTAINER = XEPDB1;
/*CREAMOS EL TABLESPACE TIENDA EN UN FICHERO LLAMADO TIENDA CON 10M*/
CREATE TABLESPACE tienda DATAFILE '/opt/oracle/oradata/tienda.dbf' SIZE 10M AUTOEXTEND ON;

/*CREAMOS UN USUARIO LLAMADO USUARIO 1 CON CONTRASEÑA USER. LO ASIGNAMOS AL TABLESPACE TIENDA SIN LIMITE DE TAMAÑO:*/
CREATE USER usuario1 IDENTIFIED BY "user" DEFAULT TABLESPACE tienda QUOTA UNLIMITED ON tienda;

/*CREAMOS UN USUARIO LLAMADO USUARIO 2 CON CONTRASEÑA USER 2. LO ASIGNAMOS CON 15M*/
CREATE USER usuario2 IDENTIFIED BY "user" DEFAULT TABLESPACE tienda QUOTA 15M ON tienda ACCOUNT LOCK;

/*DESBLOQUEAMOS AL USUARIO 2*/
ALTER USER usuario2 ACCOUNT UNLOCK;

/*ASIGNAMOS ESPACIO ILIMITADO AL USUARIO 2 EN EL TABLESPACE TIENDA*/
ALTER USER usuario2 QUOTA UNLIMITED ON tienda;

/*BORRAMOS AL USUARIO USUARIO1*/
DROP USER usuario1;

/*CONSULTAMOS LOS USUARIOS EN LA BASE DE DATOS:*/
SELECT USER_ID, SUBSTR(USERNAME,1,30) FROM DBA_USERS;

GRANT CREATE SESSION, CREATE TABLE TO usuario2;
/*CONCEDEMOS EL PERMISO DE CREAR Y EJECUTAR PROCEDIMIENTOS ALMACENADOS AL USUARIO2:*/
GRANT CREATE PROCEDURE, EXECUTE ANY PROCEDURE TO usuario2;
/*CONCEDEMOS EL PERMIO DE CREAR USUARIOS AL USURIO3 Y ESTE USUARIO PODRA CONCEDER A OTROS USUARIOS*/
CREATE USER usuario3 IDENTIFIED BY "user" DEFAULT TABLESPACE tienda QUOTA UNLIMITED ON tienda;

GRANT CREATE USER TO usuario3 WITH ADMIN OPTION;
/*CONCEDEMOS PERMISOS DE DBA AL USUARIO3*/
GRANT DBA TO usuario3;
/*REVOKACION DE PRIVILEGIOS*/

/*QUITAR TODOS LOS PRIVILEGIOS*/
SELECT * FROM dba_sys_privs WHERE GRANTEE = 'USUARIO2';

REVOKE CREATE TABLE FROM usuario2;
REVOKE EXECUTE ANY PROCEDURE FROM usuario2;
REVOKE CREATE SESSION FROM usuario2;
REVOKE CREATE PROCEDURE FROM usuario2;

SELECT * FROM dba_sys_privs WHERE GRANTEE = 'USUARIO2';

/*
—-------------------------
	Parte 6
—-------------------------
*/

-- Tabla departamentos
CREATE TABLE departamentos (
    id NUMBER PRIMARY KEY,
    nombre VARCHAR2(100)
);

INSERT INTO departamentos (id, nombre) VALUES (1, 'RRHH');

-- Tabla empleados
CREATE TABLE empleado (
    id NUMBER PRIMARY KEY,
    nombre VARCHAR2(100),
    apellidos VARCHAR2(150),
    email VARCHAR2(150) UNIQUE,
    salario NUMBER,
    dept_id NUMBER,
    CONSTRAINT fk_dept FOREIGN KEY (dept_id) REFERENCES departamentos(id)
);

/*Procedure*/
-- Procedimiento para dar de alta un empleado
CREATE OR REPLACE PROCEDURE sp_alta_empleado(
    p_nombre     IN VARCHAR2,
    p_apellidos  IN VARCHAR2,
    p_email      IN VARCHAR2,
    p_salario    IN NUMBER,
    p_dept_id    IN NUMBER,
    p_id         OUT NUMBER
)
AS
    v_existe NUMBER;
BEGIN
    -- Verificar que el departamento existe
    SELECT COUNT(*) INTO v_existe
    FROM departamentos
    WHERE id = p_dept_id;
    
    IF v_existe = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'El departamento no existe');
    END IF;
    
    -- Insertar empleado
    INSERT INTO empleado (nombre, apellidos, email, salario, dept_id)
    VALUES (p_nombre, p_apellidos, p_email, p_salario, p_dept_id)
    RETURNING id INTO p_id;
    
    COMMIT;
    
    DBMS_OUTPUT.PUT_LINE('Empleado creado con ID: ' || p_id);
    
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        RAISE_APPLICATION_ERROR(-20002, 'El email ya existe');
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END sp_alta_empleado;
/

SET SERVEROUTPUT ON;

DECLARE
    v_nuevo_id NUMBER;
BEGIN
    sp_alta_empleado(
        p_nombre    => 'Nuevo',
        p_apellidos => 'Empleado Test',
        p_email     => 'nuevo.test@empresa.com',
        p_salario   => 30000,
        p_dept_id   => 1,
        p_id        => v_nuevo_id
    );
    
    DBMS_OUTPUT.PUT_LINE('ID asignado: ' || v_nuevo_id);
END;
/

/*
—-------------------------
	Parte 7
—-------------------------
*/
-- Asegúrate de estar en la PDB correcta
ALTER SESSION SET CONTAINER = XEPDB1;

-- Tabla departamento
CREATE TABLE departamento (
    id NUMBER PRIMARY KEY,
    nombre VARCHAR2(100)
);

-- Datos de ejemplo
INSERT INTO departamento (id, nombre) VALUES (1, 'RRHH');
INSERT INTO departamento (id, nombre) VALUES (3, 'IT');

--------------------------------------------------

-- Tabla empleados2
CREATE TABLE empleados2 (
    id NUMBER PRIMARY KEY,
    nombre VARCHAR2(100),
    apellidos VARCHAR2(150),
    email VARCHAR2(150) UNIQUE,
    salario NUMBER,
    dept_id NUMBER,
    fecha_alta DATE DEFAULT SYSDATE,
    CONSTRAINT fk_dept FOREIGN KEY (dept_id) REFERENCES departamento(id)
);
-- Insertar empleados de prueba
INSERT INTO empleados2 (id, nombre, apellidos, email, salario, dept_id, fecha_alta)
VALUES (1, 'Juan', 'Perez', 'juan@empresa.com', 30000, 3, ADD_MONTHS(SYSDATE, -36));

INSERT INTO empleados2 (id, nombre, apellidos, email, salario, dept_id, fecha_alta)
VALUES (2, 'Ana', 'Lopez', 'ana@empresa.com', 28000, 3, ADD_MONTHS(SYSDATE, -60));

COMMIT;
-- Funcion para calcular antiguedad en anios
CREATE OR REPLACE FUNCTION fn_antiguedad_empleado(
    p_empleado_id IN NUMBER
)
RETURN NUMBER
AS
    v_fecha_alta DATE;
    v_antiguedad NUMBER;
BEGIN
    SELECT fecha_alta
    INTO v_fecha_alta
    FROM empleados2
    WHERE id = p_empleado_id;
    
    v_antiguedad := TRUNC(MONTHS_BETWEEN(SYSDATE, v_fecha_alta) / 12);
    
    RETURN v_antiguedad;
    
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN NULL;
END fn_antiguedad_empleado;
/

-- Uso en SELECT
SELECT nombre, apellidos, fn_antiguedad_empleado(id) AS antiguedad_anos
FROM empleados2
WHERE dept_id = 3;

/*
—-------------------------
	Parte 8
—-------------------------
*/

CREATE TABLE auditoria (
    id_auditoria NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tabla_afectada VARCHAR2(50),
    operacion VARCHAR2(10),
    registro_id NUMBER,
    datos_antes CLOB,
    datos_despues CLOB,
    usuario VARCHAR2(50) DEFAULT USER,
    fecha_operacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

/*Trigger para auditar cambios en empleados*/
CREATE OR REPLACE TRIGGER trg_auditoria_empleados
AFTER INSERT OR UPDATE OR DELETE ON empleados
FOR EACH ROW
DECLARE
    v_operacion VARCHAR2(10);
    v_datos_antes CLOB;
    v_datos_despues CLOB;
BEGIN
    /*Determinar operacion*/
    IF INSERTING THEN
        v_operacion := 'INSERT';
        v_datos_despues := 'ID=' || :NEW.id || ', Nombre=' || :NEW.nombre;
    ELSIF UPDATING THEN
        v_operacion := 'UPDATE';
        v_datos_antes := 'ID=' || :OLD.id || ', Nombre=' || :OLD.nombre;
        v_datos_despues := 'ID=' || :NEW.id || ', Nombre=' || :NEW.nombre;
    ELSIF DELETING THEN
        v_operacion := 'DELETE';
        v_datos_antes := 'ID=' || :OLD.id || ', Nombre=' || :OLD.nombre;
    END IF;
    
    /*Insertar registro de auditoria*/
    INSERT INTO auditoria (
        tabla_afectada, operacion, registro_id,
        datos_antes, datos_despues
    ) VALUES (
        'EMPLEADOS', v_operacion, NVL(:NEW.id, :OLD.id),
        v_datos_antes, v_datos_despues
    );
END;
/

/*
—-------------------------
	Parte 9
—-------------------------
*/