-- Tabla departamentos
CREATE TABLE departamentos (
    id NUMBER PRIMARY KEY,
    nombre VARCHAR2(100)
);

INSERT INTO departamentos (id, nombre) VALUES (1, 'RRHH');

-- Tabla empleados
CREATE TABLE empleado (
    id NUMBER PRIMARY KEY,
    nombre VARCHAR2(100),
    apellidos VARCHAR2(150),
    email VARCHAR2(150) UNIQUE,
    salario NUMBER,
    dept_id NUMBER,
    CONSTRAINT fk_dept FOREIGN KEY (dept_id) REFERENCES departamentos(id)
);

-- Secuencia para el ID
CREATE SEQUENCE seq_empleado START WITH 1 INCREMENT BY 1;

--------------------------------------------------

/* Procedimiento */
CREATE OR REPLACE PROCEDURE sp_alta_empleado(
    p_nombre     IN VARCHAR2,
    p_apellidos  IN VARCHAR2,
    p_email      IN VARCHAR2,
    p_salario    IN NUMBER,
    p_dept_id    IN NUMBER,
    p_id         OUT NUMBER
)
AS
    v_existe NUMBER;
BEGIN
    -- Verificar que el departamento existe
    SELECT COUNT(*) INTO v_existe
    FROM departamentos
    WHERE id = p_dept_id;
    
    IF v_existe = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'El departamento no existe');
    END IF;
    
    -- Insertar empleado usando la secuencia
    INSERT INTO empleado (id, nombre, apellidos, email, salario, dept_id)
    VALUES (seq_empleado.NEXTVAL, p_nombre, p_apellidos, p_email, p_salario, p_dept_id)
    RETURNING id INTO p_id;
    
    DBMS_OUTPUT.PUT_LINE('Empleado creado con ID: ' || p_id);

EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        RAISE_APPLICATION_ERROR(-20002, 'El email ya existe');
    WHEN OTHERS THEN
        RAISE;
END sp_alta_empleado;
/


SET SERVEROUTPUT ON;

DECLARE
    v_nuevo_id NUMBER;
BEGIN
    sp_alta_empleado(
        p_nombre    => 'Nuevo',
        p_apellidos => 'Empleado Test',
        p_email     => 'nuevo.test@empresa.com',
        p_salario   => 30000,
        p_dept_id   => 1,
        p_id        => v_nuevo_id
    );
    
    DBMS_OUTPUT.PUT_LINE('ID asignado: ' || v_nuevo_id);
END;
/

-- Funcion para calcular antiguedad en anos
CREATE OR REPLACE FUNCTION fn_antiguedad_empleado(
    p_empleado_id IN NUMBER
)
RETURN NUMBER
AS
    v_fecha_alta DATE;
    v_antiguedad NUMBER;
BEGIN
    SELECT fecha_alta
    INTO v_fecha_alta
    FROM empleado
    WHERE id = p_empleado_id;
    
    v_antiguedad := TRUNC(MONTHS_BETWEEN(SYSDATE, v_fecha_alta) / 12);
    
    RETURN v_antiguedad;
    
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN NULL;
END fn_antiguedad_empleado;
/

-- Uso en SELECT
SELECT nombre, apellidos, fn_antiguedad_empleado(id) AS antiguedad_anos
FROM empleados
WHERE dept_id = 3;