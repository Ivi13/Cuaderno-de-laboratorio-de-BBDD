-- =====================================================
-- Script: 02_schema.sql
-- Descripcion: Esquema de base de datos para RA4
-- Modulo: 0484 - Bases de Datos
-- RA: RA4 - Tratamiento de Datos
-- =====================================================

SET client_encoding = 'UTF8';

CREATE database BBDD_02;
BEGIN;

-- =====================================================
-- 1. ELIMINAR TABLAS EXISTENTES
-- =====================================================

DROP TABLE IF EXISTS auditoria CASCADE;
DROP TABLE IF EXISTS movimientos CASCADE;
DROP TABLE IF EXISTS asignaciones CASCADE;
DROP TABLE IF EXISTS proyectos CASCADE;
DROP TABLE IF EXISTS empleados CASCADE;
DROP TABLE IF EXISTS departamentos CASCADE;
DROP TABLE IF EXISTS cuentas CASCADE;
DROP TABLE IF EXISTS productos CASCADE;
DROP TABLE IF EXISTS categorias CASCADE;
DROP TABLE IF EXISTS logs CASCADE;

-- =====================================================
-- 2. CREAR TABLAS
-- =====================================================

-- Tabla departamentos
CREATE TABLE departamentos (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    ubicacion VARCHAR(100),
    presupuesto DECIMAL(12,2) DEFAULT 0 CHECK (presupuesto >= 0),
    activo BOOLEAN DEFAULT true,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE departamentos IS 'Departamentos de la empresa';
COMMENT ON COLUMN departamentos.presupuesto IS 'Presupuesto anual en euros';

-- Tabla empleados
CREATE TABLE empleados (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    salario DECIMAL(10,2) CHECK (salario >= 0),
    departamento_id INTEGER REFERENCES departamentos(id) ON DELETE SET NULL,
    fecha_contratacion DATE DEFAULT CURRENT_DATE,
    activo BOOLEAN DEFAULT true,
    fecha_modificacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE empleados IS 'Empleados de la empresa';
COMMENT ON COLUMN empleados.salario IS 'Salario anual bruto en euros';

-- Tabla proyectos
CREATE TABLE proyectos (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    fecha_inicio DATE DEFAULT CURRENT_DATE,
    fecha_fin DATE,
    presupuesto DECIMAL(12,2) CHECK (presupuesto >= 0),
    estado VARCHAR(20) DEFAULT 'planificado'
        CHECK (estado IN ('planificado', 'en_curso', 'completado', 'cancelado')),
    CONSTRAINT chk_fechas CHECK (fecha_fin IS NULL OR fecha_fin >= fecha_inicio)
);

COMMENT ON TABLE proyectos IS 'Proyectos activos de la empresa';

-- Tabla asignaciones (relacion M:N empleados-proyectos)
CREATE TABLE asignaciones (
    id SERIAL PRIMARY KEY,
    empleado_id INTEGER NOT NULL REFERENCES empleados(id) ON DELETE CASCADE,
    proyecto_id INTEGER NOT NULL REFERENCES proyectos(id) ON DELETE CASCADE,
    fecha_asignacion DATE DEFAULT CURRENT_DATE,
    rol VARCHAR(50),
    horas_asignadas INTEGER DEFAULT 0,
    UNIQUE (empleado_id, proyecto_id)
);

COMMENT ON TABLE asignaciones IS 'Asignacion de empleados a proyectos';

-- Tabla cuentas (para ejercicios de transacciones)
CREATE TABLE cuentas (
    id SERIAL PRIMARY KEY,
    titular VARCHAR(100) NOT NULL,
    saldo DECIMAL(12,2) DEFAULT 0 CHECK (saldo >= 0),
    tipo VARCHAR(20) DEFAULT 'corriente' CHECK (tipo IN ('corriente', 'ahorro', 'nomina')),
    activa BOOLEAN DEFAULT true
);

COMMENT ON TABLE cuentas IS 'Cuentas bancarias para ejercicios de transacciones';

-- Tabla movimientos
CREATE TABLE movimientos (
    id SERIAL PRIMARY KEY,
    cuenta_origen INTEGER REFERENCES cuentas(id),
    cuenta_destino INTEGER REFERENCES cuentas(id),
    monto DECIMAL(12,2) NOT NULL CHECK (monto > 0),
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    descripcion VARCHAR(200)
);

COMMENT ON TABLE movimientos IS 'Registro de movimientos bancarios';

-- Tabla categorias
CREATE TABLE categorias (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL UNIQUE,
    descripcion TEXT
);

-- Tabla productos
CREATE TABLE productos (
    id SERIAL PRIMARY KEY,
    codigo VARCHAR(20) UNIQUE NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    precio DECIMAL(10,2) CHECK (precio > 0),
    stock INTEGER DEFAULT 0 CHECK (stock >= 0),
    categoria_id INTEGER REFERENCES categorias(id),
    activo BOOLEAN DEFAULT true
);

-- Tabla logs
CREATE TABLE logs (
    id SERIAL PRIMARY KEY,
    tabla VARCHAR(50),
    operacion VARCHAR(10),
    registro_id INTEGER,
    datos JSONB,
    usuario VARCHAR(50) DEFAULT CURRENT_USER,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE logs IS 'Registro de operaciones para auditoria';

-- Tabla auditoria
CREATE TABLE auditoria (
    id SERIAL PRIMARY KEY,
    tabla VARCHAR(50),
    operacion VARCHAR(10),
    datos_anteriores JSONB,
    datos_nuevos JSONB,
    usuario VARCHAR(50) DEFAULT CURRENT_USER,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE auditoria IS 'Tabla de auditoria detallada';

-- =====================================================
-- 3. CREAR INDICES
-- =====================================================

CREATE INDEX idx_empleados_departamento ON empleados(departamento_id);
CREATE INDEX idx_empleados_email ON empleados(email);
CREATE INDEX idx_empleados_activo ON empleados(activo);
CREATE INDEX idx_asignaciones_empleado ON asignaciones(empleado_id);
CREATE INDEX idx_asignaciones_proyecto ON asignaciones(proyecto_id);
CREATE INDEX idx_productos_categoria ON productos(categoria_id);
CREATE INDEX idx_productos_codigo ON productos(codigo);
CREATE INDEX idx_logs_fecha ON logs(fecha);
CREATE INDEX idx_auditoria_fecha ON auditoria(fecha);

COMMIT;

DO $$ BEGIN RAISE NOTICE 'Esquema de base de datos creado correctamente'; END $$;