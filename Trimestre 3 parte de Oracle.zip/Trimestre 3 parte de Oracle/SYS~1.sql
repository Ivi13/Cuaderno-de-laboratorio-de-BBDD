/*Usamos la conexión correcta*/
USE SYS;

/*Muestra la pdb*/
SHOW CON_NAME;

/*Muestra la pdb en cierta dba*/
SELECT PDB_NAME FROM DBA_PDBS;

/*Trabajamos en cierto container*/
ALTER SESSION SET CONTAINER = XEPDB1;

/*Muestra la pdb en cierta dba*/
SELECT PDB_NAME FROM DBA_PDBS;

/*Trabajamos en cierto container*/
ALTER SESSION SET CONTAINER = CDB$ROOT;

/*Muestra la pdb en cierta dba*/
SELECT PDB_NAME FROM DBA_PDBS;

/*Muestra la pdb*/
SHOW CON_NAME;

/*Conectarme a la cdb como sysdba*/
CREATE PLUGGABLE DATABASE PDB_NAME
    ADMIN USER admin IDENTIFIED BY contraseña
    FILE_NAME_CONVERT = ('/ruta/a/pdbseed/', '/ruta/a/pdb_name/');

/*Ejecutar*/
ALTER PLUGGABLE DATABASE PDB_NAME OPEN;

/*lISTAR LOS PDBS*/
SELECT CON_ID, NAME, OPEN_MODE FROM V$PDBS;

/*Trabajamos en cierto conatainer*/
ALTER SESSION SET CONTAINER = <PDB_NAME>;

/*abre todos*/
ALTER PLUGGABLE DATABASE ALL OPEN;

/*Cerrar*/
ALTER PLUGGABLE DATABASE pdb_alumnos CLOSE
IMMEDIATE;

/*Muestra la pdb en cierta dba*/
select name, cdb from v$DATABASE;

/*Listar todas las pdbs disponibles*/
SHOW PDBS;

/*Conectarme a la cdb como sysdba*/
CREATE PLUGGABLE DATABASE pdb_alumnos
    ADMIN USER admin_alumnos IDENTIFIED BY Oracle123
    STORAGE UNLIMITED
    FILE_NAME_CONVERT = (
        '/opt/oracle/oradata/XE/pdbseed/',
        '/opt/oracle/oradata/XE/pdb_alumnos/'
    );
    
/*Ejecutamos la database*/
ALTER PLUGGABLE DATABASE pdb_alumnos OPEN;

/*Ejecutamos la database*/
ALTER SESSION SET CONTAINER = pdb_alumnos;

/*Creamos la tabla*/
CREATE TABLE if not exists estudiantes (
    id_ESTUDIANTE NUMBER PRIMARY KEY,
    nombre VARCHAR2(100),
    email VARCHAR2(100) UNIQUE,
    fecha_registro DATE DEFAULT SYSDATE
);

/*Insertamos en la tabla*/
INSERT INTO estudiantes (id_ESTUDIANTE, nombre, email) VALUES (1, 'Ana Perez', '3@GMAIL.COM');
INSERT INTO estudiantes (id_ESTUDIANTE, nombre, email) VALUES (2, 'Luis Gomez', '2@GMAIL.COM');
INSERT INTO estudiantes (id_ESTUDIANTE, nombre, email) VALUES (3, 'Marta Ruiz', '1@GMAIL.COM');

/*Mostramos la tabla*/
select * from estudiantes;
commit;


/*
DROP PLUGGABLE DATABASE pdb_alumnos INCLUDING DATAFILES;
*/

/*
—-------------------------
	Parte 2
—-------------------------
*/


/*
crear usuario comun  con sys (en el root)
asignarle permisos create session y dba
el usuario local se crea en la pdb (en la pdb)
asignarle permisos de create session
*/

/*Se crea el usuario con su contraseña en el root*/
ALTER SESSION SET CONTAINER = CDB$ROOT;
create user c##Ivan identified by Oracle123;

/*Se le asigna el permiso de create session*/
grant create session to c##Ivan;

/*Se le asigna el permiso DBA*/
grant DBA to c##Ivan;

/*Se crea el usuario con su contraseña en el pdb asignado en este caso: pdb_alumnos*/
create user Lope identified by Oracle123;

/*Se le asigna el permiso de create session*/
ALTER SESSION SET CONTAINER = pdb_alumnos;
grant create session to Lope;
